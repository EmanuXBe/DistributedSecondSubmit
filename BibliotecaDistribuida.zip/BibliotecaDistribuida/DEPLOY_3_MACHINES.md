# Deploy 3 máquinas (corto)

Requisitos: Java 17, repo compilado (`./gradlew build`). Ajusta IPs `<A>`, `<B>`, `<C>` según red. Usa el mismo `CP` en todos (ejemplo Linux):
```bash
CP="build/libs/BIBLIOTECA_FINAL-1.0-SNAPSHOT.jar:build/classes/java/main:$(echo ~/.gradle/caches/modules-2/files-2.1/org.zeromq/jeromq/0.5.3/*)"
```

## Máquina A (Primary – StoragePrimary)
```bash
export GA2_ROUTER_HOST=0.0.0.0
export GA2_ROUTER_PORT=5570
export GA2_REP_HOST=0.0.0.0
export GA2_REP_PORT=5580
export GA_HOST=<IP_B>
export GA_PORT=5557
java -cp "$CP" org.example.StoragePrimary
```

## Máquina B (Replica – StorageReplica)
```bash
export GA_BIND_HOST=0.0.0.0
export GA_PORT=5557
export GA2_HOST=<IP_A>
export GA2_ROUTER_PORT=5570
export GA2_REP_PORT=5580
java -cp "$CP" org.example.StorageReplica
```

## Máquina C (Front – actores y cliente)
```bash
export GC_BIND_HOST=0.0.0.0
export GC_PS_PORT=5555
export GC_PUB_PORT=5560
export ACTOR_BIND_HOST=0.0.0.0
export ACTOR_PORT=5556
export GA_HOST=<IP_B>
export GA_PORT=5557
export GA2_HOST=<IP_A>
export GA2_PORT=5580
```
Arrancar en este orden en C:
```bash
java -cp "$CP" org.example.LoanActor
java -cp "$CP" org.example.ReturnRenewalActor
export ACTOR_HOST=localhost ACTOR_PORT=5556
java -cp "$CP" org.example.LoadBalancer
export GC_HOST=<IP_C> GC_PORT=5555
java -cp "$CP" org.example.RequestProducer
```
Pruebas: en RequestProducer usa archivo `PS.txt` o escribe `PRESTAMO <ID>`, `DEVOLVER <ID>`, `RENOVAR <ID>`. Salida/archivos `DB*.txt`/`Prestamos*.txt` deben reflejar cambios. 
