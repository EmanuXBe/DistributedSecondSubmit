# Configuración en VS Code

1. Instala las extensiones necesarias:
   - "Extension pack for Java"
   - "Python"

2. Para Python:
   - No requiere ninguna configuración adicional

3. Para Java:
   - Una vez abierto el proyecto ejecuta:
   ```bash
    mvn eclipse:eclipse
    ```