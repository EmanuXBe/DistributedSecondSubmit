# Configuración en IntelliJ IDEA

1. Asegúrate de tener instalados los plugins:
    - "Maven"
    - "Python Community Edition"
    - "Protocol Buffers"

2. Para Python:
    - No requiere ninguna configuración adicional

3. Para Java:
    - Una vez abierto el proyecto, navega hasta el archivo `pom.xml` que estará en la ubicación `java_server/target/pom.xml`, haz click derecho y elige la opción de "Add as Maven Project".