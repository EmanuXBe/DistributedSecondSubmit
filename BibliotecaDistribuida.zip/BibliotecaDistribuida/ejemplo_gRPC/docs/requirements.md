# Requisitos

## Java
- Java 8+
- Maven

## Python
- Python 3.8+
- Paquetes:
  ```bash
  pip install grpcio grpcio-tools