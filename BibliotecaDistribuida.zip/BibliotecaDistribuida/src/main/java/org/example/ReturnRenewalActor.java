package org.example;

import org.zeromq.ZMQ;

public class ReturnRenewalActor {

    private static final String GC_HOST = Config.env("GC_HOST", "localhost");
    private static final String GC_PUB_PORT = Config.gcPubPort();
    private static final String GA_HOST = Config.gaHost();
    private static final String GA_PORT = Config.gaPort();
    private static final String GA2_HOST = Config.ga2Host();
    private static final String GA2_PORT = Config.ga2RepPort();

    private static final String SUB_ADDRESS = "tcp://" + GC_HOST + ":" + GC_PUB_PORT;
    private static final String GA_ADDRESS = "tcp://" + GA_HOST + ":" + GA_PORT;
    private static final String GA2_ADDRESS = "tcp://" + GA2_HOST + ":" + GA2_PORT;

    private ZMQ.Context context;
    private ZMQ.Socket subscriber;
    private ZMQ.Socket socketGA;
    private ZMQ.Socket socketGA2;

    public static void main(String[] args) {
        new ReturnRenewalActor().start();
    }

    public void start() {
        context = ZMQ.context(1);
        initSockets();

        System.out.println(" ReturnRenewalActor conectado a GC (" + SUB_ADDRESS + ") y GA (" + GA_ADDRESS + ")");

        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}

        while (!Thread.currentThread().isInterrupted()) {
            processMessages();
        }

        closeSockets();
    }

    private void initSockets() {
        subscriber = context.socket(ZMQ.SUB);
        subscriber.connect(SUB_ADDRESS);
        subscriber.subscribe("DEVOLUCION".getBytes());
        subscriber.subscribe("RENOVACION".getBytes());

        socketGA = context.socket(ZMQ.REQ);
        socketGA.connect(GA_ADDRESS);
        socketGA.setReceiveTimeOut(3000);

        socketGA2 = context.socket(ZMQ.REQ);
        socketGA2.connect(GA2_ADDRESS);
        System.out.println(" Conectado a GA2 (fallback) en " + GA2_ADDRESS);
    }

    private void processMessages() {
        String mensajeCompleto = subscriber.recvStr();
        System.out.println("\n Mensaje recibido del GC: " + mensajeCompleto);

        String[] partes = mensajeCompleto.split(" ", 2);
        String topico = partes[0];
        String contenido = partes.length > 1 ? partes[1] : "";

        if (topico.equals("DEVOLUCION")) {
            handleReturn(contenido);
        } else if (topico.equals("RENOVACION")) {
            handleRenewal(contenido);
        } else {
            System.out.println("️ Tópico desconocido: " + topico);
        }
    }

    private void handleReturn(String contenido) {
        System.out.println(" Procesando devolución -> " + contenido);
        String bookId = RequestParser.extractBookId(contenido);
        if (bookId == null) {
            System.out.println(" ID no reconocido en devolución: " + contenido);
            return;
        }
        String mensaje = "DEVOLVER " + bookId;
        String respGA = sendToGaWithFallback(mensaje);
        System.out.println(" Respuesta recibida: " + respGA);
    }

    private void handleRenewal(String contenido) {
        System.out.println(" Procesando renovación -> " + contenido);
        String bookId = RequestParser.extractBookId(contenido);
        if (bookId == null) {
            System.out.println(" ID no reconocido en renovación: " + contenido);
            return;
        }
        String mensaje = "RENOVAR " + bookId;
        String respGA = sendToGaWithFallback(mensaje);
        System.out.println(" Respuesta recibida: " + respGA);
    }

    private String sendToGaWithFallback(String mensaje) {
        try {
            socketGA.send(mensaje);
            String respuesta = socketGA.recvStr();
            if (respuesta == null) {
                System.out.println(" ⚠ GA no respondió (timeout), intentando con GA2...");
                return sendToGa2(mensaje);
            } else {
                System.out.println(" GA respondió: " + respuesta);
                return respuesta;
            }
        } catch (Exception e) {
            System.out.println(" ⚠ Error al comunicarse con GA: " + e.getMessage() + ", intentando con GA2...");
            return sendToGa2(mensaje);
        }
    }

    private String sendToGa2(String mensaje) {
        try {
            System.out.println(" Enviando solicitud a GA2 (fallback): " + mensaje);
            socketGA2.send(mensaje);
            String respuesta = socketGA2.recvStr();
            System.out.println(" ✓ Respuesta recibida de GA2 (fallback): " + respuesta);
            return respuesta;
        } catch (Exception e) {
            System.err.println(" ✗ Error al comunicarse con GA2: " + e.getMessage());
            return "Error: No se pudo comunicar ni con GA ni con GA2";
        }
    }

    private void closeSockets() {
        subscriber.close();
        socketGA.close();
        socketGA2.close();
        context.term();
        System.out.println("\n ReturnRenewalActor finalizado correctamente.");
    }
}
