package org.example;

import org.zeromq.ZMQ;

public class LoadBalancer {

    private static final String GC_BIND_HOST = Config.gcBindHost();
    private static final String PS_PORT = Config.gcPsPort();
    private static final String PUB_PORT = Config.gcPubPort();
    private static final String ACTOR_HOST = Config.actorHost();
    private static final String ACTOR_PORT = Config.actorPort();

    private static final String ADDRESS_PS = "tcp://" + GC_BIND_HOST + ":" + PS_PORT;
    private static final String ADDRESS_PUB = "tcp://" + GC_BIND_HOST + ":" + PUB_PORT;
    private static final String ADDRESS_ACTOR = "tcp://" + ACTOR_HOST + ":" + ACTOR_PORT;

    private ZMQ.Context context;
    private ZMQ.Socket socketPS;
    private ZMQ.Socket publisher;
    private ZMQ.Socket loanActor;

    public static void main(String[] args) throws InterruptedException {
        new LoadBalancer().start();
    }

    public void start() throws InterruptedException {
        context = ZMQ.context(1);
        initSockets();
        System.out.println(" LoadBalancer listening on " + ADDRESS_PS + "...");

        while (!Thread.currentThread().isInterrupted()) {
            String request = socketPS.recvStr();
            System.out.println(" Solicitud recibida: " + request);

            String response = handleRequest(request);
            socketPS.send(response, 0);

            Thread.sleep(100);
        }

        closeSockets();
    }

    private void initSockets() {
        socketPS = context.socket(ZMQ.REP);
        socketPS.bind(ADDRESS_PS);

        publisher = context.socket(ZMQ.PUB);
        publisher.bind(ADDRESS_PUB);

        loanActor = context.socket(ZMQ.REQ);
        loanActor.connect(ADDRESS_ACTOR);
    }

    private String handleRequest(String request) {
        if (request == null || request.isEmpty()) {
            return "Solicitud vacía o nula";
        }

        if (request.startsWith("DEVOLVER")) {
            return handleReturn(request);
        } else if (request.startsWith("RENOVAR")) {
            return handleRenewal(request);
        } else if (request.startsWith("PRESTAMO")) {
            return handleLoan(request);
        } else if (request.equalsIgnoreCase("PING")) {
            return "PONG";
        } else {
            System.out.println("️ Solicitud no reconocida: " + request);
            return "Solicitud no reconocida";
        }
    }

    private String handleReturn(String request) {
        System.out.println(" Procesando devolución...");
        publisher.send("DEVOLUCION " + request);
        System.out.println(" Publicado en canal DEVOLUCION: " + request);
        return "Devolución aceptada, gracias.";
    }

    private String handleRenewal(String request) {
        System.out.println(" Procesando renovación...");
        String newDate = getRenewalDate();
        publisher.send("RENOVACION " + request);
        System.out.println(" Publicado en canal RENOVACION: " + request);
        return "Renovación aceptada, nueva fecha: " + newDate;
    }

    private String handleLoan(String request) {
        System.out.println(" Procesando préstamo...");
        loanActor.send(request, 0);
        String loanResponse = loanActor.recvStr();
        System.out.println(" Respuesta del actor de préstamo: " + loanResponse);
        return loanResponse;
    }

    private String getRenewalDate() {
        java.time.LocalDate newDate = java.time.LocalDate.now().plusWeeks(1);
        return newDate.toString();
    }

    private void closeSockets() {
        socketPS.close();
        publisher.close();
        loanActor.close();
        context.term();
        System.out.println(" Sockets cerrados correctamente.");
    }
}
